Cyberblitz September Challenge.
